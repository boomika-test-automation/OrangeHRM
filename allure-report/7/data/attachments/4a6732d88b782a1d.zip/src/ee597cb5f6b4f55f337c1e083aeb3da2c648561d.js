
// pages/EmployeePage.js

const { expect } = require('@playwright/test');

class EmployeePage {
    constructor(page) {
        this.page = page;

        // LOGIN LOCATORS
        this.username = page.getByPlaceholder('Username');
        this.password = page.getByPlaceholder('Password');
        this.loginButton = page.getByRole('button', { name: 'Login' });
        this.dashboardHeading = page.getByRole('heading', {
            name: 'Dashboard'
        });

        // NAVIGATION LOCATORS
        this.pimLink = page.getByRole('link', { name: 'PIM' });
        this.addEmployeeLink = page.getByRole('link', {
            name: 'Add Employee'
        });
        this.employeeListLink = page.getByRole('link', {
            name: 'Employee List'
        });
        this.jobTab = page.getByRole('link', {
            name: 'Job',
            exact: true
        });

        // ADD EMPLOYEE LOCATORS
        this.photoInput = page.locator('input[type="file"]');
        this.firstName = page.getByPlaceholder('First Name');
        this.lastName = page.getByPlaceholder('Last Name');
        this.saveButton = page.getByRole('button', { name: 'Save' });

        // EMPLOYEE ID LOCATOR
        this.employeeIdInput = page
            .locator('.oxd-input-group')
            .filter({ hasText: 'Employee Id' })
            .locator('input');

        // SEARCH AND MESSAGES
        this.searchButton = page.getByRole('button', { name: 'Search' });
        this.successSaved = page.getByText('Successfully Saved');
        this.successUpdated = page.getByText('Successfully Updated');

        // JOB DETAILS LOCATORS
        this.jobTitleDropdown = page
            .locator('.oxd-input-group')
            .filter({ hasText: 'Job Title' })
            .locator('.oxd-select-text');

        this.employmentStatusDropdown = page
            .locator('.oxd-input-group')
            .filter({ hasText: 'Employment Status' })
            .locator('.oxd-select-text');

        this.jobTitleValue = page
            .locator('.oxd-input-group')
            .filter({ hasText: 'Job Title' })
            .locator('.oxd-select-text-input');

        this.employmentStatusValue = page
            .locator('.oxd-input-group')
            .filter({ hasText: 'Employment Status' })
            .locator('.oxd-select-text-input');

        // LOGOUT LOCATORS
        this.profilePicture = page
            .getByRole('banner')
            .getByRole('img', { name: 'profile picture' });

        this.logoutOption = page.getByRole('menuitem', {
            name: 'Logout'
        });
    }

    // 1. OPEN APPLICATION
    async open() {
        await this.page.goto(
            'https://opensource-demo.orangehrmlive.com/web/index.php/auth/login'
        );
    }

    // 2. LOGIN
    async login(username, password) {
        await this.username.fill(username);
        await this.password.fill(password);
        await this.loginButton.click();

        await expect(this.dashboardHeading).toBeVisible();
    }

    // 3. OPEN ADD EMPLOYEE
    async openAddEmployee() {
        await this.pimLink.click();
        await this.addEmployeeLink.click();
    }

    // 4. ADD EMPLOYEE
    async addEmployee(employee) {
        if (employee.photo) {
            await this.photoInput.setInputFiles(employee.photo);
        }

        await this.firstName.fill(employee.firstName);
        await this.lastName.fill(employee.lastName);

        // Capture generated employee ID before saving.
        const empId = await this.employeeIdInput.inputValue();

        await this.saveButton.click();
        await expect(this.successSaved).toBeVisible();

        expect(empId).not.toBe('');

        return empId;
    }

    // 5. SEARCH AND OPEN EMPLOYEE
    async searchEmployee(empId) {
        await this.employeeListLink.click();

        await this.employeeIdInput.fill(empId);
        await this.searchButton.click();

        const employeeRow = this.page
            .locator('.oxd-table-card')
            .filter({ has: this.page.getByText(empId, { exact: true }) });

        await expect(employeeRow).toBeVisible();
        await employeeRow.click();
    }

    // 6. OPEN JOB TAB
    async openJobTab() {
        await this.jobTab.click();
    }

    // 7. UPDATE JOB DETAILS
    async updateJobDetails(employee) {
        await this.jobTitleDropdown.click();

        await this.page.getByRole('option', {
            name: employee.jobTitle,
            exact: true
        }).click();

        await this.employmentStatusDropdown.click();

        await this.page.getByRole('option', {
            name: employee.employmentStatus,
            exact: true
        }).click();

        await this.saveButton.click();

        await expect(this.successUpdated).toBeVisible();
    }

    // 8. VERIFY JOB DETAILS IN UI
    async verifyJobDetails(employee) {
        await expect(this.jobTitleValue)
            .toHaveText(employee.jobTitle);

        await expect(this.employmentStatusValue)
            .toHaveText(employee.employmentStatus);
    }

    // 9. API HELPER
    async requestEmployeeAPI(endpoint) {
        const response = await this.page.request.get(
            `https://opensource-demo.orangehrmlive.com${endpoint}`,
            {
                headers: {
                    Accept: 'application/json'
                }
            }
        );

        const responseText = await response.text();

        if (!response.ok()) {
            throw new Error(
                `API request failed: GET ${endpoint}. ` +
                `HTTP ${response.status()}. Response: ${responseText}`
            );
        }

        let body;

        try {
            body = JSON.parse(responseText);
        } catch {
            throw new Error(
                `API returned a non-JSON response for ${endpoint}: ` +
                responseText.slice(0, 300)
            );
        }

        return body;
    }

    // 10. VALIDATE EMPLOYEE THROUGH API
    async validateEmployeeAPI(empId, employee) {
        console.log(`Validating employee ID ${empId} through API`);

        // Fetch employee identity.
        const employeeResponse = await this.requestEmployeeAPI(
            `/web/index.php/api/v2/pim/employees/${encodeURIComponent(empId)}?model=detailed`
        );

        const apiEmployee = employeeResponse.data;

        expect(
            apiEmployee,
            'Employee should exist in the API response'
        ).toBeTruthy();

        expect(String(apiEmployee.empNumber)).toBe(String(empId));
        expect(apiEmployee.firstName).toBe(employee.firstName);
        expect(apiEmployee.lastName).toBe(employee.lastName);

        console.log('Employee identity matches the test data.');

        // Fetch job details from the job-details endpoint.
        const jobResponse = await this.requestEmployeeAPI(
            `/web/index.php/api/v2/pim/employees/${encodeURIComponent(empId)}/job-details`
        );

        const apiJob = Array.isArray(jobResponse.data)
            ? jobResponse.data[0]
            : jobResponse.data;

        expect(
            apiJob,
            'Job details should exist in the API response'
        ).toBeTruthy();

        // OrangeHRM can return dropdown values as objects.
        const actualJobTitle =
            typeof apiJob.jobTitle === 'object'
                ? apiJob.jobTitle?.title ?? apiJob.jobTitle?.name
                : apiJob.jobTitle;

        const actualEmploymentStatus =
            typeof apiJob.employmentStatus === 'object'
                ? apiJob.employmentStatus?.name ??
                  apiJob.employmentStatus?.title
                : apiJob.employmentStatus;

        // If the response uses different field names, fail clearly.
        expect(
            actualJobTitle,
            'API response must contain the job title'
        ).toBeTruthy();

        expect(
            actualEmploymentStatus,
            'API response must contain the employment status'
        ).toBeTruthy();

        // Compare API values with the values entered in the test.
        expect(actualJobTitle).toBe(employee.jobTitle);

        expect(actualEmploymentStatus)
            .toBe(employee.employmentStatus);

        console.log('API employee validation passed.');
        console.log(`Employee ID: ${empId}`);
        console.log(`First name: ${apiEmployee.firstName}`);
        console.log(`Last name: ${apiEmployee.lastName}`);
        console.log(`Job title: ${actualJobTitle}`);
        console.log(`Employment status: ${actualEmploymentStatus}`);
    }

    // 11. DELETE EMPLOYEE
    async deleteEmployee(empId) {
        await this.employeeListLink.click();

        await this.employeeIdInput.fill(empId);
        await this.searchButton.click();

        const employeeRow = this.page
            .locator('.oxd-table-card')
            .filter({ has: this.page.getByText(empId, { exact: true }) });

        await expect(employeeRow).toBeVisible();

        await employeeRow.locator('button').last().click();

        await this.page.getByRole('button', {
            name: /Yes,\s*Delete/
        }).click();

        await expect(
            this.page.getByText('Successfully Deleted')
        ).toBeVisible();
    }

    // 12. LOGOUT
    async logout() {
        await this.profilePicture.click();
        await this.logoutOption.click();

        await expect(this.username).toBeVisible();
    }
}

module.exports = { EmployeePage };
